# godotino CLI

> Write Arduino firmware in Go. Transpile. Flash.

```
   ██████╗  ██████╗ ██████╗  ██████╗ ████████╗██╗███╗   ██╗ ██████╗
  ██╔════╝ ██╔═══██╗██╔══██╗██╔═══██╗╚══██╔══╝██║████╗  ██║██╔═══██╗
  ██║  ███╗██║   ██║██║  ██║██║   ██║   ██║   ██║██╔██╗ ██║██║   ██║
  ██║   ██║██║   ██║██║  ██║██║   ██║   ██║   ██║██║╚██╗██║██║   ██║
  ╚██████╔╝╚██████╔╝██████╔╝╚██████╔╝   ██║   ██║██║ ╚████║╚██████╔╝
   ╚═════╝  ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝   ╚═╝╚═╝  ╚═══╝ ╚═════╝
```

## Installation

### From source

```bash
# Clone repo
git clone https://github.com/godotino/cli
cd cli

# Build and install (requires Go 1.21+)
make install          # installs to /usr/local/bin
make install-user     # installs to ~/bin (no sudo)
make install-all      # installs CLI + godotino-core
```

### Quick install (Linux/macOS)

```bash
curl -sSfL https://raw.githubusercontent.com/godotino/cli/main/install.sh | sh
```

---

## Commands

### `godotino init`

Initialize a new project.

```bash
godotino init
godotino init my-robot
godotino init my-robot --board esp32
```

Creates:
```
my-robot/
├── goduino.json     ← project manifest
├── src/
│   └── main.go      ← blink skeleton
└── .gitignore
```

---

### `godotino build`

Transpile Go → C++ (and optionally compile with `arduino-cli`).

```bash
godotino build
godotino build --board esp32
godotino build --compile              # also invoke arduino-cli compile
godotino build --compile --output dist/
godotino build --source-map           # emit #line pragmas
```

---

### `godotino upload`

Upload compiled firmware to the connected board.

```bash
godotino upload
godotino upload --port /dev/ttyUSB0
godotino upload --port COM3 --board uno
```

Auto-detects the board via `arduino-cli board list` if `--port` is omitted.

---

### `godotino check`

Validate source files without building. Renders rich tracebacks for errors.

```bash
godotino check
godotino check --board esp32
```

---

### `godotino config`

Manage CLI configuration. Renders a styled panel — inspired by Python's `rich` library.

```bash
# Show all config
godotino config show
godotino config show --raw         # key=value pairs

# Set a key
godotino config set default_board esp32
godotino config set arduino_cli /usr/local/bin/arduino-cli
godotino config set verbose true
godotino config set default_baud 115200

# Get a key
godotino config get default_board
godotino config get default_board --raw   # raw value only

# Where is the config file?
godotino config path
```

**Config keys:**

| Key | Default | Description |
|-----|---------|-------------|
| `core_binary` | `""` | Path to `godotino-core` binary |
| `arduino_cli` | `arduino-cli` | Path to `arduino-cli` |
| `default_board` | `uno` | Default target board |
| `default_baud` | `9600` | Default serial baud rate |
| `color` | `true` | Enable colored output |
| `verbose` | `false` | Verbose output |
| `auto_detect` | `true` | Auto-detect connected boards |

---

### `godotino boards`

```bash
godotino boards list      # show all supported boards
godotino boards detect    # detect connected boards via USB
```

---

### `godotino clean`

Remove the `build/` directory.

```bash
godotino clean
```

---

## Global flags

| Flag | Description |
|------|-------------|
| `--verbose` / `-v` | Verbose output |
| `--no-color` | Disable colored output |

---

## Error output

`godotino` renders transpilation and compilation errors as **rich tracebacks**,
styled after Python's [`rich`](https://github.com/Textualize/rich) library:

```
╭─── Traceback (most recent call last) ─────────────────────────────────╮
│  src/main.go:14 in main                                                │
│                                                                        │
│   12 │ func loop() {                                                   │
│   13 │     arduino.PinMode(13, arduino.OUTPUT)                        │
│ ❱ 14 │     Delay(1000)                                                │
│   15 │ }                                                               │
│                                                                        │
│  locals ───────────────────────────────────────────────────────────── │
│  │  file = src/main.go                                                │
│  │  line = 14                                                         │
╰────────────────────────────────────────────────────────────────────────╯
TranspileError: undefined function `Delay` — did you mean `arduino.Delay`?
```

---

## Architecture

```
godotino (Go CLI)
├── cmd/godotino/main.go          ← entry point
└── internal/
    ├── cli/                      ← cobra commands
    │   ├── root.go               ← root command + banner
    │   ├── init.go
    │   ├── build.go
    │   ├── upload.go
    │   ├── check.go
    │   ├── config.go
    │   └── boards.go
    ├── manifest/                 ← goduino.json load/save
    ├── config/                   ← ~/.config/godotino/config.json
    ├── core/                     ← shell-out to godotino-core
    ├── build/                    ← transpile + arduino-cli compile
    ├── flash/                    ← arduino-cli upload
    ├── check/                    ← source validation + report
    └── ui/                       ← rich terminal output
        ├── colors
        ├── boxes / borders
        ├── tracebacks
        ├── config display
        └── spinners / progress bars
```

The CLI is a thin orchestrator — all transpilation is delegated to `godotino-core` (Rust).

---

## Requirements

- **Go 1.21+**
- **[godotino-core](https://github.com/godotino/core)** — Rust transpiler binary
- **[arduino-cli](https://arduino.github.io/arduino-cli/)** — for `build --compile` and `upload`
